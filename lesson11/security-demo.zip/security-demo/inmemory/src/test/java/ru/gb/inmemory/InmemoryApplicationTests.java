package ru.gb.inmemory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InmemoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
